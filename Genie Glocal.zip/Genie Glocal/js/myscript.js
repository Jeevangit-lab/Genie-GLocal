var ctx = document.getElementById('myChart').getContext('2d');
var myChart = new Chart(ctx, {
    type: 'bar',
    data: {
        labels: ['', '', '', '', '', '','','','',''],        
        datasets: [{
            label: '',
            data: [300, 275, 250, 260, 350, 255, 300, 350, 275, 250],
            backgroundColor: [
                '#2d3436',
                '#2d3436',
                '#eb4d4b',
                '#eb4d4b',
                '#2d3436',
                '#2d3436',
                '#2d3436',
                '#2d3436',
                '#2d3436',
                '#eb4d4b'
            ],                       
            borderWidth: 0  
        }]
    },
    options: {        
        scales: {
            yAxes: [{
                ticks: {
                    beginAtZero: true
                }
            }]
        }
    }
});


var ctx2 = document.getElementById("lineChart").getContext("2d");
var lineChart = new Chart(ctx2, {
    type: 'line',
    data: {
      labels: ["","","","","","","","","","","",""],
      datasets: [{ 
          data: [500,700,500,800,450,600,450,800,500,700,500,600],
          label: "",
          borderColor: "#0abde3",
          fill: false
        },
      ]
    },
    options: {
      title: {
        display: true,               
      }
    }
  });

var ctx3 = document.getElementById("lineChart2").getContext("2d");
var lineChart2 = new Chart(ctx3, {
    type: 'line',
    data: {
      labels: ["","","","","","","",""],
      datasets: [{ 
          data: [300,500,350,550,350,550,250,300],
          label: "",
          borderColor: "#44bd32",
          fill: false
        },
      ]
    },
    options: {
      title: {
        display: true,               
      }
    }
  });


